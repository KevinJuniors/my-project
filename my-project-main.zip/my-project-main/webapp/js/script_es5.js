"use strict";

var numAdd = function numAdd(x, y) {
    return x + y;
};

console.log(add(2, 3));
