const numAdd = (x, y) => {
    return x + y
}

console.log(add (2, 3));